//Objective:  a program for DND games
//Name: Sandhya Nayar 
/*game design: 4 endings
Structure: base --SPLIT-- (A,B) --SPLIT--(A1,A2,B1, B2)*/


//libraries
#include <fstream>
#include <iostream>
using namespace std;

//Programmer defined data types
struct Story{
  string name;
  int format;
  string plot[30];
};

//Special compiler dependent definitions
//NONE

//global constants/variables
//NONE

//Programmer defined functions
void readFile(string aLine); //read the game file
int formatChoices();
void getStoryFormatOne();
void getStoryFormatThree();
void getStoryFormatTwo();


//main program
int main()
{
  

  //prompt user for input file
  string inputFile;
  cout << "Welcome to the Dungeons and Dragons Test Build." << endl;
  int test = formatChoices();
  /*while (true) {
    cout << "Please enter input file:" ;
    getline(cin, inputFile);

    //open input file
    ifstream fin; 
    fin.open(inputFile); 
    if (!fin.good()) throw "I/O error"; 

    //save lines
    while(fin.good()){

      //get first line
      getline(fin, title);
      getline(fin, base);

      //get second line
      getline(fin, ABp);

      //get third line
      getline(fin, Ap);

      //get 4th line
      getline(fin, Ar);

      //get 5th line 
      getline(fin, Bp);

      //get6th
      getline(fin, Br);

      //get 7th
      getline(fin, A1A2p);

      getline(fin, A1p);
      getline(fin, A1r);
      getline(fin, A2p);
      getline(fin, A2r);
      getline(fin, B1B2p);
      getline(fin, B1p);
      getline(fin, B1r);
      getline(fin,B2p);
      getline(fin, B2r);
    }
    fin.close();

    //game output

    //intro 
    cout << endl;
    cout << "You are playing: " << title << endl;
    cout << "Starting game in..." ;
    cout << "3..." ;
    cout << "2...";
    cout << "1..." << endl;
    cout << "-----------------------------------------------------------------------------" << endl;


    while (true)
    {
      //game start prompt
      aLine = base;
      readFile(aLine);

      //first pathway

      //prompt
      aLine = ABp;
      readFile(aLine);
      cout << endl;

      cout << "1: " << Ap << endl;
      cout << "2: " << Bp << endl;
      cin >> choice;
      cin.ignore(1000,10);

      //AB split
      if (choice == 1){
        cout << endl;
        aLine = Ar; //result from A pathway
        readFile(aLine); 

        cout << endl;
        aLine = A1A2p; 
        readFile(aLine);
        cout << endl;
  
        cout << "1: " << A1p << endl;
        cout << "2: " << A2p << endl;
        cin >> choice;
        cin.ignore(1000,10);

        if(choice == 1){
          cout << endl;
          aLine = A1r; //A1r ending
          readFile(aLine);

          //ending sequence
          cout << "." ;
    
          cout << "." ;
    
          cout << "." ;
    
          cout << "You have reached a Bad ending." << endl;

        }

        if(choice == 2){
          aLine = A2r; //A2r ending
          readFile(aLine);

          //ending sequence
          cout << "." ;
    
          cout << "." ;
    
          cout << "." ;
    
          cout << "You have reached a Bad ending." << endl;
        }

      }
      if (choice == 2){
        cout << endl;
        aLine = Br; //Br ending
        readFile(aLine);

        cout << endl;
        aLine = B1B2p; 
        readFile(aLine);
        cout << endl;
  
        cout << "1: " << B1p << endl;
        cout << "2: " << B2p << endl;
        cin >> choice;
        cin.ignore(1000,10);

        if(choice == 1){
          aLine = B1r;
          readFile(aLine); //b1r ending
          cout << endl;

          //ending sequence
          cout << "." ;
    
          cout << "." ;
    
          cout << "." ;
    
          cout << "Congratulations! You reached the Happy Ending...but at what cost..." << endl;
        }

        if(choice == 2){
          aLine = B2r; 
          readFile(aLine); //B2r ending

          //ending sequence
          cout << "." ;
    
          cout << "." ;
    
          cout << "." ;
    
          cout << "You have reached a Bad ending." << endl;
        }
      }

      //prompt player to play again
      char again;
      cout << "Would you like to play this game again? [Y / N]" << endl;
      cin >> again;
      if (again == 'N' || again == 'n') break;
      if (again == 'Y' || again == 'y') {
        cout << "Restarting game in..." ;
        cout.flush();
  
        cout << "3..." ;
        cout.flush();
  
        cout << "2...";
        cout.flush();
  
        cout << "1..." << endl;
        cout.flush();
  
        cout << "-----------------------------------------------------------------------------" << endl;
      }

    }//end of game loop

    char newFile;
    cout << "Would you like to try a new game? [Y/N]" << endl;
    cin >> newFile;
    if (newFile == 'N' || newFile== 'n') {
      cout << "Come back soon! Love, Sandy" << endl;
      break;
    }
    if (newFile == 'Y' || newFile == 'y') {
      cout << "Restarting" ;
      cout.flush();

      cout << "." ;
      cout.flush();

      cout << ".";
      cout.flush();

      cout << "." << endl;
      cout.flush();

    }
    
  } //end of input loop*/
  

  
}//main

void readFile(string aLine){ 
  cout << endl;

  for(int i = 0; i < aLine.length();i++){
    if (aLine[i] == '.'){
      cout << aLine[i] ;
      cout << endl;
    }
    else cout << aLine[i] ;
  }
  cout << endl;
}

void writeStory(){
  string storyName;
  int format = 0;

  cout << "Please name your story: " << endl;
  getline(cin, storyName);
  format = formatChoices();
  

  //get story
  string plot[format];
  if(format == 14) getStoryFormatOne();
  if (format == 20) getStoryFormatTwo();
  if (format == 30) getStoryFormatThree();
  

  //create new obj 
  /*Story a = new Story;
  a.name = storyName;
  a.format = format;
  a.plot = plot[format];*/

}

void getStoryFormatOne(){
  string plot[14];
  cout << "Write your premise. This is the start of your story and the first thing players will see before they're presented with the first crossroad." << endl;
  cout << "Premise: ";
  getline(cin, plot[0]);
  cout << "Alright, now that that's done, we need to present your players with their first crossroad. " << endl;
  cout << "Crossroad 1: ";
  getline(cin, plot[1]);
  cout << "Enter their first choice (1): ";
  getline(cin, plot[2]);
  cout << "Enter their second choice (2): ";
  getline(cin, plot[3]);
  cout << "Now write the result of the first choice and its crossroad (Crossroad 2): ";
  getline(cin, plot[4]);
  cout << "Enter their first choice (1a): ";
  getline(cin, plot[5]);
  cout << "Enter their second choice (1b): ";
  getline(cin, plot[6]);
  cout << "Enter the first result from 1a: ";
  getline(cin, plot[7]);
  cout << "Enter the second result from 1b: ";
  getline(cin, plot[8]);
  cout << "Now write the result of the second choice and its crossroad (Crossroad 3): ";
  getline (cin, plot[9]);
  cout << "Enter their first choice (2a): ";
  getline(cin, plot[10]);
  cout << "Enter their second choice (2b): ";
  getline(cin, plot[11]);
  cout << "Enter the first result from 2a: ";
  getline(cin, plot[12]);
  cout << "Enter the second result from 2b: ";
  getline(cin, plot[13]);

}

void getStoryFormatTwo(){

}

void getStoryFormatThree(){

}

int formatChoices(){
  int formatChoice = 0;
  int format = 0;

  //output formats
  cout << "These are the format choices: " << endl;
  cout << "FORMAT 1: " << endl;
  cout << "       |      " << endl;
  cout << "      / \    " << endl;
  cout << "     /\ /\    " << endl;
  cout << endl;
  cout << "FORMAT 2: " << endl;
  cout << "       |      " << endl;
  cout << "     / | \     " << endl;
  cout << "    /\ /\ /\    " << endl;
  cout << endl;
  cout << "FORMAT 3: " << endl;
  cout << "       |      " << endl;
  cout << "     /   \    " << endl;
  cout << "    /\    /\    " << endl;
  cout << "   /\ /\ /\ /\ " << endl;
  cout << endl;
  cout << "Please choose your format: ";
  cin >> formatChoice;
  switch(formatChoice){
    case 1:
    format = 14;
    break;
    case 2:
    format = 20;
    break;
    case 3:
    format = 30;
    break;
    default:
    cout << "Invalid response" << endl;
  }
  return format;
}