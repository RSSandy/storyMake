import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    System.out.println("Welcome to Arc, a story game.");

    //menu
    System.out.println("Opening menu:");
    int choice = openMenu();
    if (choice == 1) //TO-DO: library setup
    if (choice == 2) {
      Story a = new Story();
      makeStory();
    }

    
  }

  public static void chooseLibrary(){

  }

  public static void playGame(Story a){


  }

  public static int openMenu(){
    System.out.println("1: Play a game from the library");
    System.out.println("2: Make your own story game");
    Scanner in =  new Scanner(System.in);
    int choice = in.nextInt();

    return choice;
  }
}

public class Story{ //why can't i make this public
  public String name;
  public int format;
  public String[] plot;

  public static void makeStory(){

    //name
    System.out.print("Please name your story: ");
    Scanner in = new Scanner(System.in);
    String name = in.nextLine();

    //format
    System.out.println("Now let's choose the format of your story." );
    int format = chooseFormat();

    //get plot
    String [] plot = getPlot(format);


    //create object
    Story temp = new Story();
    temp.name = name;
    temp.format = format;
    temp.plot = plot;

  }

  public static int chooseFormat(){
    int format = 0;

    //output formats
    System.out.println("These are the format choices: ");
    /*System.out.println(  "FORMAT 1: "  );
    System.out.println(  "       |    ");  
    System.out.println(  "      / \    "); 
    System.out.println(  "     /\ /\  ");  
    System.out.println;
    System.out.println(  "FORMAT 2: "  );
    System.out.println(  "       |    ");  
    System.out.println(  "     / | \   "); 
    System.out.println(  "    /\ /\ /\  ");  
    System.out.println; 
    System.out.println(  "FORMAT 3: "  );
    System.out.println(  "       |    ");  
    System.out.println(  "     /   \  ");  
    System.out.println(  "    /\    /\ "); "  
    System.out.println(  "   /\ /\ /\ /\" );  
    System.out.println; */
    System.out.print(  "Please choose your format: ");
    Scanner in =  new Scanner(System.in);
    int choice = in.nextInt();

    switch(choice){
      case 1:
      format = 14;
      break;
      case 2:
      format = 20;
      break;
      case 3:
      format = 30;
      break;
      default:
      System.out.println(  "Invalid response" );  
    }
    return format;
  }

  public static String[] getPlot(int format){
    String[] plot = new String[format];
    if(format ==14){
      System.out.println( "Write your premise. This is the start of your story and the first thing players will see before they're presented with the first crossroad." );
      System.out.println( "Premise: ");
      //plot[0];
      System.out.println( "Alright, now that that's done, we need to present your players with their first crossroad. " );
      System.out.println( "Crossroad 1: ");
      //[1]);
      System.out.println( "Enter their first choice (1): ");
      //[2]);
      System.out.println( "Enter their second choice (2): ");
      //[3]);
      System.out.println( "Now write the result of the first choice and its crossroad (Crossroad 2): ");
      //[4]);
      System.out.println( "Enter their first choice (1a): ");
      //[5]);
      System.out.println( "Enter their second choice (1b): ");
      //[6]);
      System.out.println( "Enter the first result from 1a: ");
      //[7]);
      System.out.println( "Enter the second result from 1b: ");
      //[8]);
      System.out.println( "Now write the result of the second choice and its crossroad (Crossroad 3): ");
      //getline ([9]);
      System.out.println( "Enter their first choice (2a): ");
      //[10]);
      System.out.println( "Enter their second choice (2b): ");
      //[11]);
      System.out.println( "Enter the first result from 2a: ");
      //[12]);
      System.out.println( "Enter the second result from 2b: ");
      //[13]);
    }
    if(format == 20){
      System.out.println( "Write your premise. This is the start of your story and the first thing players will see before they're presented with the first crossroad." );
      System.out.println( "Premise: ");
      //plot[0];
      System.out.println( "Alright, now that that's done, we need to present your players with their first crossroad. " );
      System.out.println( "Crossroad 1: ");
      //[1]);
      System.out.println( "Enter their first choice (1): ");
      //[2]);
      System.out.println( "Enter their second choice (2): ");
      //[3]);
      System.out.println( "Enter their third choice (3): ");
      //4
      System.out.println( "Now write the result of the first choice (1) and its crossroad (Crossroad 2): ");
      //5
      System.out.println( "Enter their first choice (1a): ");
      //[6]);
      System.out.println( "Enter their second choice (1b): ");
      //[7]);
      System.out.println( "Enter the first result from 1a: ");
      //[8]);
      System.out.println( "Enter the second result from 1b: ");
      //[9]);
      System.out.println( "Now write the result of the second choice (2) and its crossroad (Crossroad 3): ");
      //getline ([10]);
      System.out.println( "Enter their first choice (2a): ");
      //[11]);
      System.out.println( "Enter their second choice (2b): ");
      //[13]);
      System.out.println( "Enter the first result from 2a: ");
      //[14]);
      System.out.println( "Enter the second result from 2b: ");
      //[15]);
      System.out.println( "Now write the result of the third choice (3) and its crossroad (Crossroad 4): ");
      //16
      System.out.println( "Enter their first choice (3a): ");
      //17
      System.out.println( "Enter their second choice (3b): ");
      //18
      System.out.println( "Enter the first result from 3a: ");
      //19
      System.out.println("Enter the second result from 3b: ");
      //20
    }

    if (format == 30) System.out.println("hella lines"); //TO-DO: write later
    
  return plot;
  }
 


}//class story